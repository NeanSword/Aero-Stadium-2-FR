Aero-Stadium-2-FR — patch minimal pour PokemonStadium2_FR_Windows_Next

1) Garde ton dossier existant "pokestadiumgs-fr".
2) Extrais ce ZIP dans le dossier qui contient "pokestadiumgs-fr".
3) Autorise la fusion des dossiers.
4) Ne supprime aucun fichier existant.

Ce ZIP contient uniquement les fichiers nécessaires au prochain test NP3F :
- vérification de la ROM locale ;
- catalogue des 88 fragments ;
- validation du YAML candidat ;
- lancement de Splat avec capture du log.

Aucune ROM n'est incluse.

Ta ROM française reste ici :
    pokestadiumgs-fr\baseroms\fr\baserom.z64

Après extraction, depuis :
    PokemonStadium2_FR_Windows_Next\pokestadiumgs-fr

Lance :

    .\windows\verify_np3f.ps1

Puis, avec ton YAML déjà présent :

    .\windows\run_np3f_extract.ps1 -CandidateYaml "CHEMIN\VERS\yamls_fr_relocated_candidate.yaml"

Le log sera :
    build\NP3F_SPLAT_EXTRACT.log

Le but de ce test est de valider le raccord entre ton projet local actuel et le workflow NP3F du dépôt GitHub.
